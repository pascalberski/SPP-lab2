#pragma once

#define AUTHORS_ONE_A "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_ONE_B "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"

#define AUTHORS_TWO_A "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_TWO_B "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_TWO_C "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_TWO_D "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_TWO_E "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_TWO_F "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"

#define AUTHORS_THREE_A "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_THREE_B "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_THREE_C "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_THREE_D "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_THREE_E "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"
#define AUTHORS_THREE_F "Dobrin Georgiev, Khanh Huyen Nguyen, Pascal Berski"